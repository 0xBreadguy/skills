# Smart Contract Patterns (MegaEVM)

> **Spec-awareness note:** Most guidance here targets the current documented MegaEVM / REX5-era behavior. Keep upgrade-specific caveats only when debugging historical behavior or validating implementation/spec deltas on older network states.

## MegaEVM vs Standard EVM

MegaEVM is fully compatible with Ethereum contracts but has different:
- **Gas costs** (especially SSTORE)
- **Block metadata limits** (volatile data access)
- **Contract size limits** (512 KB)

## Contract Limits

| Resource | TX Limit | Block Limit |
|----------|----------|-------------|
| Contract code | 512 KB | — |
| Calldata | 128 KB | — |
| State growth | 1,000 slots | 1,000 slots |
| eth_call/estimateGas | 10M gas (public) | higher on VIP |

**Note:** The last tx in a block can push state growth past 1,000 — post-execution limits allow the exceeding tx to be included, then the block closes.

### Per-Frame State Growth (Rex4)

Inner call frames receive 98% of the parent's remaining state growth budget. If exceeded, the child frame **reverts** (not halts), returning `MegaLimitExceeded(3, limit)`. The parent can catch and continue.

### MegaAccessControl — Volatile Data Opt-Out (Rex4)

Contracts can disable volatile data access for inner calls via the system contract at `0x6342000000000000000000000000000000000004`:

```solidity
// Prevent untrusted callees from triggering the 20M gas cap
IMegaAccessControl(0x6342000000000000000000000000000000000004).disableVolatileDataAccess();
(bool ok, ) = untrusted.call(data); // block.timestamp here reverts, not gas detention
IMegaAccessControl(0x6342000000000000000000000000000000000004).enableVolatileDataAccess();
```

## Volatile Data Access Control

Accessing block metadata triggers gas detention with a **relative** 20M post-access compute cap. The transaction may consume up to 20M additional compute gas after the volatile access; the cap is transaction-scoped and continues to apply across parent/child/sibling frames.

**Affected opcodes:**
- `TIMESTAMP`, `NUMBER`, `BLOCKHASH`, `BASEFEE`, `PREVRANDAO`, `GASLIMIT`, `COINBASE`, `BLOBBASEFEE`, `BLOBHASH`
- Any access to the beneficiary account (`BALANCE`, `EXTCODESIZE`, `EXTCODEHASH` on coinbase address)
- Oracle contract SLOAD (also 20M cap since Rex3; was 1M pre-Rex3)

```solidity
// ❌ Front-loading compute does not avoid detention; the 20M post-access budget still applies
function process() external {
    for (uint i = 0; i < 10000; i++) {
        // Burns >20M compute gas...
    }
    uint256 ts = block.timestamp;  // Immediately OOGs — total already exceeds 20M
}

// ❌ Also fails — same reason
function process() external {
    uint256 ts = block.timestamp;  // Sets 20M total cap
    for (uint i = 0; i < 10000; i++) {
        // Will OOG once cumulative compute gas exceeds 20M
    }
}

// ✅ Keep total compute gas under 20M when using block metadata
function process() external {
    uint256 ts = block.timestamp;
    // Light computation only — stay under 20M total
    lastUpdated = ts;
    emit Processed(ts);
}

// ✅ For high-precision time without the cap, use the timestamp oracle
function process() external {
    uint256 microTs = ITimestampOracle(ORACLE).readTimestamp();
    // Oracle SLOAD has its own 20M cap (Rex3), but separate from block env
    // Heavy computation is fine if you don't also touch block.timestamp
}
```

**Key insight:** If your contract needs both heavy computation AND time-awareness, split them into separate transactions or use the timestamp oracle.

**Spec:** https://github.com/megaeth-labs/mega-evm/blob/main/specs/MiniRex.md#28-volatile-data-access-control

## High-Precision Timestamps

For microsecond precision, use the oracle instead of `block.timestamp`:

```solidity
interface ITimestampOracle {
    /// @notice Returns timestamp in microseconds
    function timestamp() external view returns (uint256);
}

contract MyContract {
    ITimestampOracle constant ORACLE = 
        ITimestampOracle(0x6342000000000000000000000000000000000002);
    
    function getTime() external view returns (uint256) {
        return ORACLE.timestamp(); // Microseconds, not seconds
    }
}
```

## Storage Patterns

### Avoid Dynamic Mappings

```solidity
// ❌ Expensive: each new key = new storage slot = 2M+ gas
mapping(address => uint256) public balances;

// ✅ Better: fixed-size or use RedBlackTreeLib
uint256[100] public fixedBalances;
```

### Solady RedBlackTreeLib

```solidity
import {RedBlackTreeLib} from "solady/src/utils/RedBlackTreeLib.sol";

contract OptimizedStorage {
    using RedBlackTreeLib for RedBlackTreeLib.Tree;
    RedBlackTreeLib.Tree private _tree;
    
    // Tree manages contiguous storage slots
    // Insert/remove reuses slots instead of allocating new ones
    
    function insert(uint256 key, uint256 value) external {
        _tree.insert(key);
        // Store value in separate packed array
    }
}
```

## Gas Estimation

Always use remote estimation:

```solidity
// foundry.toml
[profile.default]
# Don't rely on local simulation
```

```bash
# Deploy with explicit gas, skip simulation
forge script Deploy.s.sol \
    --rpc-url https://mainnet.megaeth.com/rpc \
    --gas-limit 5000000 \
    --skip-simulation \
    --broadcast
```

## Events and Logs

LOG opcodes have quadratic cost above 4KB data:

```solidity
// ❌ Expensive: large event data
event LargeData(bytes data); // If data > 4KB, quadratic cost

// ✅ Better: emit hash, store off-chain
event DataStored(bytes32 indexed hash);
```

## SELFDESTRUCT

EIP-6780 style SELFDESTRUCT is being implemented. Check current status:
- Same-tx destruction works
- Cross-tx destruction behavior may vary

## Deployment Patterns

### Factory Contracts

```solidity
contract Factory {
    function deploy(bytes32 salt, bytes memory bytecode) 
        external 
        returns (address) 
    {
        address addr;
        assembly {
            addr := create2(0, add(bytecode, 32), mload(bytecode), salt)
        }
        require(addr != address(0), "Deploy failed");
        return addr;
    }
}
```

### Proxy Patterns

Standard proxy patterns (EIP-1967, UUPS, Transparent) work normally. Consider:
- Storage slot allocation costs on first write
- Upgrade authorization patterns

## Testing Contracts

```solidity
// Use Foundry with remote RPC
contract MyTest is Test {
    function setUp() public {
        // Fork MegaETH testnet for realistic gas costs
        vm.createSelectFork("https://carrot.megaeth.com/rpc");
    }
    
    function testGasCost() public {
        uint256 gasBefore = gasleft();
        // Your operation
        uint256 gasUsed = gasBefore - gasleft();
        console.log("Gas used:", gasUsed);
    }
}
```

## SSTORE2: On-Chain Data Storage

For storing large immutable data on-chain (HTML, images, metadata), use the **SSTORE2** pattern — store data as contract bytecode instead of storage slots.

### Why SSTORE2 on MegaETH?

| Approach | Write Cost | Read Cost |
|----------|------------|-----------|
| SSTORE (storage slots) | 2M+ gas per new slot | 100-2100 gas |
| SSTORE2 (bytecode) | ~10K gas per byte | **FREE** (EXTCODECOPY) |

SSTORE2 is ideal for write-once, read-many data — content is immutable once deployed.

### How It Works

1. Deploy a contract with data as bytecode
2. Read data via `EXTCODECOPY` (no gas for view calls)

```solidity
// Writing: Deploy data as contract bytecode
library SSTORE2 {
    function write(bytes memory data) internal returns (address) {
        // Prepend STOP opcode so contract can't be called
        bytes memory bytecode = abi.encodePacked(
            hex"00", // STOP opcode
            data
        );
        
        address pointer;
        assembly {
            pointer := create(0, add(bytecode, 32), mload(bytecode))
        }
        require(pointer != address(0), "Deploy failed");
        return pointer;
    }
    
    function read(address pointer) internal view returns (bytes memory) {
        uint256 size;
        assembly { size := extcodesize(pointer) }
        
        bytes memory data = new bytes(size - 1); // Skip STOP opcode
        assembly {
            extcodecopy(pointer, add(data, 32), 1, sub(size, 1))
        }
        return data;
    }
}
```

### MegaETH Gas Estimation for SSTORE2

```javascript
// MegaETH multidimensional gas model for bytecode deployment
const MEGAETH_GAS = {
  INTRINSIC_COMPUTE: 21_000n,
  INTRINSIC_STORAGE: 39_000n,
  CONTRACT_CREATION_COMPUTE: 32_000n,
  CODE_DEPOSIT_PER_BYTE: 10_000n,
  CALLDATA_NONZERO_PER_BYTE: 160n,
};

function estimateDeployGas(dataSizeBytes) {
  const dataSize = BigInt(dataSizeBytes);
  
  const computeGas = MEGAETH_GAS.INTRINSIC_COMPUTE 
    + MEGAETH_GAS.CONTRACT_CREATION_COMPUTE;
  
  const storageGas = MEGAETH_GAS.INTRINSIC_STORAGE
    + (dataSize * MEGAETH_GAS.CODE_DEPOSIT_PER_BYTE)
    + (dataSize * MEGAETH_GAS.CALLDATA_NONZERO_PER_BYTE);
  
  return (computeGas + storageGas) * 150n / 100n; // 50% buffer
}
```

### Use Cases

- **On-chain websites/HTML** — permanent, censorship-resistant hosting
- **NFT metadata** — fully on-chain images/JSON
- **Large configs** — immutable protocol parameters
- **Data availability** — store proofs, attestations

### Chunking Large Data

For data > 24KB, chunk into multiple contracts:

```javascript
const CHUNK_SIZE = 15000; // 15KB per chunk

function chunkData(data) {
  const chunks = [];
  for (let i = 0; i < data.length; i += CHUNK_SIZE) {
    chunks.push(data.slice(i, i + CHUNK_SIZE));
  }
  return chunks;
}
```

### Solady Implementation

Solady provides an optimized SSTORE2:

```solidity
import {SSTORE2} from "solady/src/utils/SSTORE2.sol";

// Write
address pointer = SSTORE2.write(data);

// Read
bytes memory data = SSTORE2.read(pointer);
```

**Reference implementation note:** For end-to-end examples of large-payload SSTORE2 deployment patterns on MegaETH, look to ecosystem-specific skills in Awesome MegaETH AI rather than treating any one application integration as part of this core stack.

## EIP-6909: Minimal Multi-Token Standard

For contracts managing multiple token types, prefer [EIP-6909](https://eips.ethereum.org/EIPS/eip-6909) over ERC-1155.

### Why EIP-6909 on MegaETH?

| Feature | MegaETH Benefit |
|---------|-----------------|
| No mandatory callbacks | Less gas, simpler integrations |
| No batching in spec | Allows MegaETH-optimized implementations |
| Single contract | Fewer SSTORE operations (expensive) |
| Granular approvals | Per-token-ID OR full operator access |
| Minimal interface | Smaller bytecode |

### Storage Efficiency

One EIP-6909 contract vs. N separate ERC-20 contracts:

```solidity
// ❌ Deploying many ERC-20s = many new storage slots
// Each contract: new code, new storage initialization

// ✅ Single EIP-6909 = shared storage
// Multiple token IDs in one contract, slot reuse
```

### Basic Implementation

```solidity
// Using Solady's ERC6909 (gas-optimized)
import {ERC6909} from "solady/src/tokens/ERC6909.sol";

contract MultiToken is ERC6909 {
    function name(uint256 id) public view override returns (string memory) {
        // Return name for token ID
    }
    
    function symbol(uint256 id) public view override returns (string memory) {
        // Return symbol for token ID
    }
    
    function tokenURI(uint256 id) public view override returns (string memory) {
        // Return metadata URI for token ID
    }
    
    function mint(address to, uint256 id, uint256 amount) external {
        _mint(to, id, amount);
    }
}
```

### Key Differences from ERC-1155

| | ERC-1155 | EIP-6909 |
|-|----------|----------|
| Callbacks | Required | None |
| Batch transfers | In spec | Implementation choice |
| Approvals | Operator only | Operator + per-ID allowance |
| Complexity | Higher | Minimal |

### Use Cases

- **DEXes**: LP tokens for multiple pairs in one contract
- **Games**: Multiple item/asset types
- **DeFi vaults**: Multiple share classes
- **NFT editions**: Fungible editions of NFTs

### Solady Implementation

Solady provides a gas-optimized EIP-6909:
```bash
forge install vectorized/solady
```

```solidity
import {ERC6909} from "solady/src/tokens/ERC6909.sol";
```

**Docs**: https://github.com/Vectorized/solady/blob/main/src/tokens/ERC6909.sol

## OP Stack Compatibility

MegaETH uses OP Stack. Standard bridge contracts and predeploys are available:

| Contract | Address |
|----------|---------|
| WETH9 | `0x4200000000000000000000000000000000000006` |
| Multicall3 | `0xcA11bde05977b3631167028862bE2a173976CA11` |
| L2CrossDomainMessenger | `0x4200000000000000000000000000000000000007` |

See OP Stack docs for full predeploy list.

## On-Chain SVG / Metadata Generation

MegaETH's 512KB contract size limit makes on-chain SVG generation practical. Key patterns:

### Stack Depth Management

SVG generation hits stack-too-deep easily. Each `internal pure` function gets its own stack frame:

```solidity
// ❌ One big function — stack-too-deep
function generateSVG() internal pure returns (string memory) {
    string memory bg = ...;
    string memory border = ...;
    string memory name = ...;
    string memory info = ...;  // Stack overflow
    return string.concat(bg, border, name, info);
}

// ✅ Split into small functions — each gets its own stack
function _svg() internal pure returns (string memory) {
    string memory part1 = string.concat(_svgOpen(), _svgBg());
    string memory part2 = _svgCorners();
    string memory part3 = string.concat(_svgName(), _svgInfo(), _svgClose());
    return string.concat(part1, part2, part3);
}

function _svgBg() internal pure returns (string memory) { ... }
function _svgCorners() internal pure returns (string memory) { ... }
function _svgName() internal pure returns (string memory) { ... }
```

### Parameter Packing

When you need to pass many values between functions, pack into fixed-size arrays:

```solidity
// ❌ Too many params — stack overflow
function _render(string memory a, uint256 b, uint64 c, bool d, string memory e, uint8 f) ...

// ✅ Pack into array
function _render(uint256[6] memory params) internal pure returns (string memory) { ... }
```

### Upgradeable Renderer Pattern

Instead of proxy patterns, use a swappable external renderer for NFT metadata:

```solidity
address public tokenURIRenderer;

function tokenURI(uint256 tokenId) public view override returns (string memory) {
    if (tokenURIRenderer != address(0)) {
        return ITokenURIRenderer(tokenURIRenderer).tokenURI(tokenId);
    }
    return _defaultTokenURI(tokenId); // Built-in fallback
}

function setTokenURIRenderer(address renderer) external onlyOwner {
    tokenURIRenderer = renderer;
}
```

This lets you iterate NFT visuals by deploying new renderer contracts without touching the main contract. Keep renderers **stateless** (read from the main contract) so redeployment needs zero migration.

## Etherscan V2 API (Contract Verification)

MegaETH uses the Etherscan V2 API with chain ID parameter:

```bash
# V2 endpoint (preferred)
https://api.etherscan.io/v2/api?chainid=4326

# Verify contract
forge verify-contract <address> src/MyContract.sol:MyContract \
  --chain 4326 \
  --etherscan-api-key $ETHERSCAN_KEY \
  --verifier-url "https://api.etherscan.io/v2/api?chainid=4326"

# Explorer
https://mega.etherscan.io
```

## Common Issues

### "Intrinsic gas too low"
Local simulation uses wrong opcode costs. Use `--skip-simulation` or remote estimation. For large contracts (25KB+ bytecode), use `--gas-limit 500000000` (500M).

### `via_ir` silently breaks return values
**Never use `via_ir=true`** in foundry.toml. It can cause functions to return 0 instead of correct values with no compiler error. Use `optimizer=true` with `optimizer_runs=200` instead.

### "Out of gas" after block.timestamp
Hitting volatile data access limit. Restructure to access metadata late.

### Transaction stuck
Check nonce with `eth_getTransactionCount` using `pending` tag.
